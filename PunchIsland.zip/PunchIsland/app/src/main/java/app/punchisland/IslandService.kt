package app.punchisland

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.MediaStore
import android.text.TextUtils
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

/** Damped spring (0 = smooth ease-out, 1 = very bouncy). */
class Spring(private val b: Float) : TimeInterpolator {
    override fun getInterpolation(t: Float): Float {
        if (t >= 1f) return 1f
        if (b < 0.02f) { val u = 1f - t; return 1f - u * u * u }
        val z = 1f - 0.5f * b
        val wn = 6f / z
        val wd = wn * sqrt(1f - z * z)
        val d = z * wn
        return 1f - exp(-d * t) * (cos(wd * t) + d / wd * sin(wd * t))
    }
}

class Eq(c: Context) : View(c) {
    var color = Color.WHITE
    private var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun run(b: Boolean) { on = b; invalidate() }
    override fun onDraw(cv: Canvas) {
        val n = 4
        val gap = width * 0.14f
        val bw = (width - gap * (n - 1)) / n
        val t = SystemClock.uptimeMillis() / 1000f
        p.color = color
        for (i in 0 until n) {
            val a = if (on) 0.3f + 0.7f * abs(sin(t * (3.2f + i * 1.1f) + i * 1.7f)) else 0.22f
            val bh = height * a
            val x = i * (bw + gap)
            val y = (height - bh) / 2
            cv.drawRoundRect(x, y, x + bw, y + bh, bw / 2, bw / 2, p)
        }
        if (on && isShown) postInvalidateOnAnimation()
    }
}

class Bar(c: Context) : View(c) {
    var frac = 0f
    var color = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val r = height / 2f
        p.color = Color.argb(60, 255, 255, 255)
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, p)
        p.color = color
        cv.drawRoundRect(0f, 0f, width * frac.coerceIn(0f, 1f), height.toFloat(), r, r, p)
    }
}

class IslandService : AccessibilityService() {
    companion object { @Volatile var instance: IslandService? = null }

    private enum class S { HIDDEN, COMPACT, EXPANDED }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private var st = S.HIDDEN
    private var info: MediaInfo? = null
    private var anim: ValueAnimator? = null
    private var torch = false
    private var lastArt: Bitmap? = null
    private var lastAcc = Color.WHITE

    // style (px unless noted)
    private var sPillW = 0; private var sPillH = 0; private var sExpW = 0; private var sExpH = 0; private var sRad = 0
    private var sOffX = 0; private var sOffY = 0; private var sDur = 450L; private var sBounce = 0.4f
    private var sNotch = false; private var sAccent = true; private var sEq = true; private var sColor = Color.BLACK
    // geometry
    private var cx = 0; private var top = 0; private var holeD = 0
    private var cw = 0; private var ch = 0; private var cr = 0f

    private var root: FrameLayout? = null
    private var body: FrameLayout? = null
    private val bg = GradientDrawable()
    private lateinit var compact: FrameLayout
    private lateinit var full: LinearLayout
    private lateinit var artS: ImageView
    private lateinit var artB: ImageView
    private lateinit var eqS: Eq
    private lateinit var eqB: Eq
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var play: TextView
    private lateinit var bar: Bar

    private val tick = object : Runnable {
        override fun run() {
            val m = info
            if (m != null && m.dur > 0 && st != S.HIDDEN) { bar.frac = m.position().toFloat() / m.dur; bar.invalidate() }
            if (st == S.EXPANDED) h.postDelayed(this, 500)
        }
    }
    private val autoHide = Runnable { if (st == S.COMPACT && info?.playing != true) hide() }
    private val demoEnd = Runnable {
        val real = MediaBus.current
        info = real
        if (st == S.COMPACT && real?.playing != true) hide()
    }
    private val restyle = Runnable {
        anim?.cancel(); removeRoot(); st = S.HIDDEN
        val real = MediaBus.current
        if (real != null && real.playing) { info = real; show() } else demo()
    }
    private val prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        h.removeCallbacks(restyle); h.postDelayed(restyle, 150)
    }

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sp = Prefs.sp(this)
        sp.registerOnSharedPreferenceChangeListener(prefL)
        loadStyle()
        MediaBus.listener = { onMedia(it) }
        MediaBus.current?.let { onMedia(it) }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        anim?.cancel(); removeRoot(); st = S.HIDDEN
        val m = MediaBus.current
        info = m
        if (m != null && m.playing) show()
    }

    override fun onUnbind(intent: Intent?): Boolean { cleanup(); return super.onUnbind(intent) }
    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        anim?.cancel(); removeRoot(); st = S.HIDDEN
        if (instance === this) instance = null
        MediaBus.listener = null
        try { sp.unregisterOnSharedPreferenceChangeListener(prefL) } catch (e: Exception) { }
    }

    // ---------- media ----------
    private fun onMedia(m: MediaInfo?) {
        info = m
        if (m != null && m.playing && st == S.HIDDEN) show()
        else if (m != null && root != null && st != S.HIDDEN) bind(m)
        if (m != null && m.playing) h.removeCallbacks(autoHide) else scheduleAutoHide()
    }

    private fun scheduleAutoHide() {
        h.removeCallbacks(autoHide)
        if (info?.playing != true) h.postDelayed(autoHide, 4000)
    }

    /** Shows a fake "now playing" island for 4 s (used by Test button and live style preview). */
    fun demo() {
        h.post {
            val real = MediaBus.current
            if (real != null && real.playing) return@post
            val d = MediaInfo("Preview", "Punch Island", null, true, 0L, 180000L, SystemClock.elapsedRealtime(), 1f, null)
            info = d
            if (st == S.HIDDEN) show() else if (root != null) bind(d)
            h.removeCallbacks(demoEnd); h.postDelayed(demoEnd, 4000)
        }
    }

    // ---------- geometry ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun loadStyle() {
        fun i(k: String) = Prefs.int(sp, k)
        val maxW = resources.displayMetrics.widthPixels
        sPillW = dp(i("pillW")); sPillH = dp(i("pillH"))
        sExpW = min(dp(i("expW")), maxW - dp(16)); sExpH = dp(i("expH")); sRad = dp(i("radius"))
        sOffX = dp(i("offX")); sOffY = dp(i("offY"))
        sDur = i("dur").toLong(); sBounce = i("bounce") / 100f
        sNotch = sp.getBoolean("notch", false)
        sAccent = sp.getBoolean("accent", true)
        sEq = sp.getBoolean("eq", true)
        sColor = Color.parseColor(Prefs.colors[sp.getInt("color", 0).coerceIn(0, Prefs.colors.lastIndex)])
    }

    /** Finds the camera hole (API 30+); otherwise falls back to top-centre. Sliders fine-tune it. */
    private fun locate() {
        val dm = resources.displayMetrics
        var x = dm.widthPixels / 2f
        var y = statusBarH() / 2f
        var d = dp(22).toFloat()
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val r = wm.currentWindowMetrics.windowInsets.displayCutout?.boundingRects?.minByOrNull { it.top }
                if (r != null && r.top < dm.heightPixels / 4 && r.width() < dm.widthPixels) {
                    x = r.exactCenterX(); y = r.exactCenterY(); d = min(r.width(), r.height()).toFloat()
                }
            } catch (e: Exception) { }
        }
        cx = (x + sOffX).roundToInt()
        top = max(0, (y - sPillH / 2f + sOffY).roundToInt())
        holeD = d.coerceIn(dp(8).toFloat(), sPillH.toFloat()).roundToInt()
    }

    private fun winLp(bw: Int, bh: Int): WindowManager.LayoutParams {
        val w = bw + dp(48)
        val lp = WindowManager.LayoutParams(
            w, bh + dp(32), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = cx - w / 2
        lp.y = top
        if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        lp.title = "PunchIsland"
        return lp
    }

    private fun resizeWindow(bw: Int, bh: Int) {
        root?.let { try { wm.updateViewLayout(it, winLp(bw, bh)) } catch (e: Exception) { } }
    }

    private fun removeRoot() {
        root?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        root = null; body = null
    }

    // ---------- views ----------
    private fun rounded(v: View, f: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(x: View, o: Outline) { o.setRoundRect(0, 0, x.width, x.height, min(x.width, x.height) * f) }
        }
        v.clipToOutline = true
    }

    private fun glyph(t: String, size: Float, circle: Boolean, click: (TextView) -> Unit): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = size; v.gravity = Gravity.CENTER; v.setTextColor(Color.WHITE)
        if (circle) v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(Color.argb(38, 255, 255, 255))
        }
        v.setOnClickListener { click(v) }
        return v
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }

    private fun build() {
        val r = FrameLayout(this)
        r.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && st == S.EXPANDED) { collapse(); true } else false
        }
        val b = FrameLayout(this)
        bg.setColor(sColor)
        b.background = bg
        b.clipToOutline = true
        b.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, if (sNotch) -cr.roundToInt() else 0, v.width, v.height, cr)
            }
        }
        b.setOnClickListener { if (st == S.COMPACT) expand() else if (st == S.EXPANDED) collapse() }
        r.addView(b, FrameLayout.LayoutParams(sPillW, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // compact pill: artwork left, equalizer right (the middle is the camera hole)
        val a = (sPillH * 0.6f).roundToInt()
        val pad = (sPillH * 0.28f).roundToInt()
        compact = FrameLayout(this)
        artS = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        rounded(artS, 0.28f)
        compact.addView(artS, FrameLayout.LayoutParams(a, a, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = pad })
        eqS = Eq(this)
        compact.addView(eqS, FrameLayout.LayoutParams(a, (a * 0.8f).roundToInt(), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = pad })
        b.addView(compact, FrameLayout.LayoutParams(sPillW, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // expanded: now playing + controls + quick buttons
        full = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            alpha = 0f; visibility = View.INVISIBLE
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        artB = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        rounded(artB, 0.2f)
        head.addView(artB, LinearLayout.LayoutParams(dp(52), dp(52)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        artist = TextView(this).apply {
            setTextColor(Color.argb(179, 255, 255, 255)); textSize = 13f
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(title); col.addView(artist)
        head.addView(col, LinearLayout.LayoutParams(0, WC, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        eqB = Eq(this)
        head.addView(eqB, LinearLayout.LayoutParams(dp(22), dp(18)))
        full.addView(head, LinearLayout.LayoutParams(MP, WC))

        bar = Bar(this)
        full.addView(bar, LinearLayout.LayoutParams(MP, dp(4)).apply { topMargin = dp(12) })

        val ctr = row()
        ctr.addView(glyph("⏮", 24f, false) { info?.ctl?.transportControls?.skipToPrevious() }, LinearLayout.LayoutParams(dp(60), MP))
        play = glyph("⏸", 30f, false) {
            val m = info
            if (m != null) {
                val t = m.ctl?.transportControls
                if (t != null) { if (m.playing) t.pause() else t.play() }
            }
        }
        ctr.addView(play, LinearLayout.LayoutParams(dp(60), MP))
        ctr.addView(glyph("⏭", 24f, false) { info?.ctl?.transportControls?.skipToNext() }, LinearLayout.LayoutParams(dp(60), MP))
        full.addView(ctr, LinearLayout.LayoutParams(MP, 0, 1f))

        val act = row()
        fun lp() = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(9), 0, dp(9), 0) }
        act.addView(glyph("🔦", 17f, true) { torchToggle(it) }, lp())
        act.addView(glyph("📷", 17f, true) { launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, lp())
        act.addView(glyph("⏱", 17f, true) { launch(Intent(AlarmClock.ACTION_SHOW_TIMERS)) }, lp())
        act.addView(glyph("📸", 17f, true) { shot() }, lp())
        act.addView(glyph("🔒", 17f, true) { global(GLOBAL_ACTION_LOCK_SCREEN) }, lp())
        full.addView(act, LinearLayout.LayoutParams(MP, dp(40)))
        b.addView(full, FrameLayout.LayoutParams(sExpW, sExpH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        root = r; body = b
    }

    private fun accentOf(b: Bitmap): Int = try {
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        if (hsv[1] < 0.15f) Color.WHITE else { hsv[1] = max(hsv[1], 0.5f); hsv[2] = max(hsv[2], 0.9f); Color.HSVToColor(hsv) }
    } catch (e: Exception) { Color.WHITE }

    private fun bind(m: MediaInfo) {
        title.text = m.title
        artist.text = m.artist
        val bm = m.art
        if (bm != null) { artS.setImageBitmap(bm); artB.setImageBitmap(bm) }
        else { artS.setImageDrawable(ColorDrawable(Color.DKGRAY)); artB.setImageDrawable(ColorDrawable(Color.DKGRAY)) }
        play.text = if (m.playing) "⏸" else "▶"
        if (bm !== lastArt) { lastArt = bm; lastAcc = if (bm != null) accentOf(bm) else Color.WHITE }
        val acc = if (sAccent) lastAcc else Color.WHITE
        eqS.color = acc; eqB.color = acc; bar.color = acc
        val vis = if (sEq) View.VISIBLE else View.INVISIBLE
        eqS.visibility = vis; eqB.visibility = vis
        eqS.run(m.playing && sEq); eqB.run(m.playing && sEq)
        h.post(tick)
    }

    // ---------- animation ----------
    private fun place(w: Int, hh: Int, r: Float) {
        val b = body ?: return
        cw = w; ch = hh; cr = r
        val lp = b.layoutParams as FrameLayout.LayoutParams
        lp.width = w; lp.height = hh; lp.topMargin = max(0, (sPillH - hh) / 2)
        b.layoutParams = lp
        val t = if (sNotch) 0f else r
        bg.cornerRadii = floatArrayOf(t, t, t, t, r, r, r, r)
        b.invalidateOutline()
    }

    private fun morph(tw: Int, th: Int, tr: Float, end: (() -> Unit)?) {
        anim?.cancel()
        val w0 = cw; val h0 = ch; val r0 = cr
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = sDur
        a.interpolator = Spring(sBounce)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            val w = (w0 + (tw - w0) * f).roundToInt().coerceAtLeast(1)
            val hh = (h0 + (th - h0) * f).roundToInt().coerceAtLeast(1)
            place(w, hh, (r0 + (tr - r0) * f).coerceIn(0f, min(w, hh) / 2f))
        }
        a.addListener(object : AnimatorListenerAdapter() {
            var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) {
                if (cancelled) return
                place(tw, th, tr.coerceIn(0f, min(tw, th) / 2f))
                end?.invoke()
            }
        })
        anim = a
        a.start()
    }

    private fun show() {
        if (st != S.HIDDEN) return
        if (resources.configuration.orientation != Configuration.ORIENTATION_PORTRAIT) return
        anim?.cancel(); removeRoot()
        loadStyle(); locate(); build()
        try { wm.addView(root, winLp(sPillW, sPillH)) } catch (e: Exception) { removeRoot(); return }
        st = S.COMPACT
        place(holeD, holeD, holeD / 2f)           // start as a dot exactly over the camera hole
        info?.let { bind(it) }
        compact.alpha = 0f
        compact.animate().alpha(1f).setStartDelay(sDur * 35 / 100).setDuration(sDur * 40 / 100).start()
        morph(sPillW, sPillH, sPillH / 2f, null)  // the widening animation
    }

    private fun hide() {
        if (st == S.HIDDEN) return
        h.removeCallbacks(tick); h.removeCallbacks(autoHide)
        st = S.HIDDEN
        val d = sDur * 25 / 100
        compact.animate().alpha(0f).setStartDelay(0).setDuration(d).start()
        full.animate().alpha(0f).setStartDelay(0).setDuration(d).start()
        morph(holeD, holeD, holeD / 2f) { removeRoot() }
    }

    private fun expand() {
        if (st != S.COMPACT) return
        st = S.EXPANDED
        h.removeCallbacks(autoHide)
        resizeWindow(sExpW, sExpH)
        compact.animate().alpha(0f).setStartDelay(0).setDuration(sDur * 25 / 100).start()
        full.visibility = View.VISIBLE
        full.alpha = 0f; full.scaleX = 0.9f; full.scaleY = 0.9f
        full.pivotX = sExpW / 2f; full.pivotY = 0f
        full.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(sDur * 30 / 100).setDuration(sDur * 55 / 100).start()
        morph(sExpW, sExpH, sRad.toFloat(), null)
        h.post(tick)
    }

    private fun collapse() {
        if (st != S.EXPANDED) return
        st = S.COMPACT
        h.removeCallbacks(tick)
        full.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setStartDelay(0).setDuration(sDur * 25 / 100)
            .withEndAction { full.visibility = View.INVISIBLE }.start()
        compact.animate().alpha(1f).setStartDelay(sDur * 35 / 100).setDuration(sDur * 40 / 100).start()
        morph(sPillW, sPillH, sPillH / 2f) {
            if (st == S.COMPACT) resizeWindow(sPillW, sPillH)
            scheduleAutoHide()
        }
    }

    // ---------- quick buttons ----------
    private fun launch(i: Intent) {
        collapse()
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) } catch (e: Exception) { }
    }

    private fun global(action: Int) {
        collapse()
        h.postDelayed({ if (Build.VERSION.SDK_INT >= 28) performGlobalAction(action) }, 300)
    }

    private fun shot() {
        root?.visibility = View.INVISIBLE      // screenshot without the island
        collapse()
        h.postDelayed({ if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) }, 450)
        h.postDelayed({ root?.visibility = View.VISIBLE }, 1800)
    }

    private fun torchToggle(v: TextView) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torch = !torch
            cm.setTorchMode(id, torch)
            (v.background as? GradientDrawable)?.setColor(if (torch) Color.argb(230, 255, 214, 10) else Color.argb(38, 255, 255, 255))
        } catch (e: Exception) { }
    }
}
