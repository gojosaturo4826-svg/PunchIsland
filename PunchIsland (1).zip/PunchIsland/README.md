# Punch Island
Dynamic-island overlay for punch-hole Android phones (Android 8+). Idle = nothing drawn (your real camera hole).
Play media -> the hole widens into a pill. Tap the pill -> expanded player + quick buttons.

## Build
- Android Studio: open this folder, press Run.
- No PC: push this folder to a GitHub repo -> Actions -> "Build APK" -> download the `PunchIsland-apk` artifact.

## Set up
1. Open the app. Enable **Accessibility** (draws the island) and **Notification access** (reads media).
2. Sideloaded on Android 13+: Settings > Apps > Punch Island > ⋮ > *Allow restricted settings* first.
3. Tap **Test island**, then nudge the position sliders until the pill grows exactly out of your camera hole.
