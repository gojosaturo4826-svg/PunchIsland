package app.punchisland

import android.content.Context
import android.content.SharedPreferences

class Slider(val key: String, val label: String, val min: Int, val max: Int, val def: Int, val unit: String)

object Prefs {
    val sliders = listOf(
        Slider("pillW", "Pill width", 100, 260, 150, "dp"),
        Slider("pillH", "Pill height", 24, 56, 36, "dp"),
        Slider("expW", "Expanded width", 260, 380, 340, "dp"),
        Slider("expH", "Expanded height", 230, 340, 268, "dp"),
        Slider("radius", "Expanded corner radius", 20, 56, 40, "dp"),
        Slider("offX", "Horizontal position", -60, 60, 0, "dp"),
        Slider("offY", "Vertical position", -30, 30, 0, "dp"),
        Slider("dur", "Animation time", 150, 900, 450, "ms"),
        Slider("bounce", "Bounce", 0, 100, 40, "%")
    )
    val colors = listOf("#000000", "#1C1C1E", "#0B1A33", "#2A0F3D", "#0F2A1D", "#3A0D0D")

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    fun int(sp: SharedPreferences, k: String): Int = sp.getInt(k, sliders.first { it.key == k }.def)
}
