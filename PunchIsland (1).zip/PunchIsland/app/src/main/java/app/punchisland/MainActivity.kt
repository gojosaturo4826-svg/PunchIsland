package app.punchisland

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var bA: Button
    private lateinit var bN: Button
    private val dots = ArrayList<View>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun toggle(t: String, k: String, d: Boolean) = Switch(this).apply {
        text = t; setTextColor(Color.WHITE); isChecked = sp.getBoolean(k, d)
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, on -> sp.edit().putBoolean(k, on).apply() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        sp = Prefs.sp(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(40))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101012")); addView(col) })

        col.addView(label("Punch Island", 26f, true))
        col.addView(label("Turn your camera hole into a dynamic island.").apply { alpha = 0.7f; setPadding(0, 0, 0, dp(16)) })

        bA = Button(this).apply { setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        bN = Button(this).apply { setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
        col.addView(bA); col.addView(bN)
        col.addView(Button(this).apply {
            text = "▶  Test island"
            setOnClickListener {
                val i = IslandService.instance
                if (i == null) Toast.makeText(this@MainActivity, "Enable accessibility first", Toast.LENGTH_SHORT).show() else i.demo()
            }
        })

        col.addView(label("Style", 18f, true).apply { setPadding(0, dp(24), 0, dp(8)) })
        col.addView(label("Color").apply { alpha = 0.7f })
        val sw = LinearLayout(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        Prefs.colors.forEachIndexed { i, _ ->
            val v = View(this)
            v.setOnClickListener { sp.edit().putInt("color", i).apply(); paint() }
            dots.add(v)
            sw.addView(v, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) })
        }
        col.addView(sw)
        paint()

        col.addView(toggle("Notch style (flat top)", "notch", false))
        col.addView(toggle("Equalizer", "eq", true))
        col.addView(toggle("Accent color from artwork", "accent", true))
        col.addView(toggle("Pop-ups for Wi-Fi, Bluetooth, DND, charging...", "pop", true))
        col.addView(toggle("Second circle when two things are active", "bubble", true))

        Prefs.sliders.forEach { s ->
            val lab = label("").apply { setPadding(0, dp(14), 0, 0) }
            fun upd(v: Int) { lab.text = "${s.label}: $v${s.unit}" }
            val cur = Prefs.int(sp, s.key)
            upd(cur)
            val sb = SeekBar(this).apply {
                max = s.max - s.min
                progress = cur - s.min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(b: SeekBar, p: Int, user: Boolean) {
                        val v = p + s.min
                        upd(v)
                        if (user) sp.edit().putInt(s.key, v).apply()
                    }
                    override fun onStartTrackingTouch(b: SeekBar) {}
                    override fun onStopTrackingTouch(b: SeekBar) {}
                })
            }
            col.addView(lab); col.addView(sb)
        }

        col.addView(Button(this).apply {
            text = "Reset style"
            setOnClickListener { sp.edit().clear().apply(); recreate() }
        })
        col.addView(label("Sideloaded on Android 13+? Open Settings > Apps > Punch Island > ⋮ > Allow restricted settings, then enable both permissions above.", 12f)
            .apply { alpha = 0.6f; setPadding(0, dp(16), 0, 0) })
    }

    override fun onResume() {
        super.onResume()
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        bA.text = (if (acc.contains("$packageName/") && acc.contains("IslandService")) "✅ " else "⬜ ") + "1 · Accessibility (draws the island)"
        bN.text = (if (nl.contains(packageName)) "✅ " else "⬜ ") + "2 · Notification access (reads media)"
    }

    private fun paint() {
        val cur = sp.getInt("color", 0)
        dots.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(Prefs.colors[i]))
                setStroke(dp(3), if (i == cur) Color.WHITE else Color.parseColor("#555555"))
            }
        }
    }
}
