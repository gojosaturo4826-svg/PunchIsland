package app.punchisland

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService

class MediaInfo(
    val title: String, val artist: String, val art: Bitmap?, val playing: Boolean,
    val pos: Long, val dur: Long, val stamp: Long, val speed: Float, val ctl: MediaController?,
    val pkg: String = ""
) {
    fun position(): Long =
        if (playing) pos + ((SystemClock.elapsedRealtime() - stamp) * speed).toLong() else pos
}

object MediaBus {
    @Volatile var current: MediaInfo? = null
    @Volatile var listener: ((MediaInfo?) -> Unit)? = null
    fun push(m: MediaInfo?) { current = m; listener?.invoke(m) }
}

class MediaListener : NotificationListenerService() {
    private val cn by lazy { ComponentName(this, MediaListener::class.java) }
    private var msm: MediaSessionManager? = null
    private val regs = ArrayList<MediaController>()

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { publish() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { publish() }
        override fun onSessionDestroyed() { resync() }
    }
    private val sessL = MediaSessionManager.OnActiveSessionsChangedListener { sync(it) }

    override fun onListenerConnected() {
        val m = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessL, cn)
            sync(m.getActiveSessions(cn))
        } catch (e: SecurityException) { }
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessL) } catch (e: Exception) { }
        regs.forEach { it.unregisterCallback(cb) }
        regs.clear()
        MediaBus.push(null)
    }

    private fun resync() {
        try { sync(msm?.getActiveSessions(cn)) } catch (e: Exception) { }
    }

    private fun sync(list: List<MediaController>?) {
        regs.forEach { it.unregisterCallback(cb) }
        regs.clear()
        list?.forEach { it.registerCallback(cb); regs.add(it) }
        publish()
    }

    private fun publish() {
        val c = regs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: regs.firstOrNull()
        val ps = c?.playbackState
        if (c == null || ps == null || ps.state == PlaybackState.STATE_NONE || ps.state == PlaybackState.STATE_STOPPED) {
            MediaBus.push(null); return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        MediaBus.push(MediaInfo(
            title, artist, art, ps.state == PlaybackState.STATE_PLAYING,
            ps.position, md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            ps.lastPositionUpdateTime, ps.playbackSpeed, c, c.packageName
        ))
    }
}
