package app.punchisland

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.MediaStore
import android.text.TextUtils
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
private typealias FLP = FrameLayout.LayoutParams
private typealias LLP = LinearLayout.LayoutParams

/** Damped spring (0 = smooth ease-out, 1 = very bouncy). */
class Spring(private val b: Float) : TimeInterpolator {
    override fun getInterpolation(t: Float): Float {
        if (t >= 1f) return 1f
        if (b < 0.02f) { val u = 1f - t; return 1f - u * u * u }
        val z = 1f - 0.5f * b
        val wn = 6f / z
        val wd = wn * sqrt(1f - z * z)
        val d = z * wn
        return 1f - exp(-d * t) * (cos(wd * t) + d / wd * sin(wd * t))
    }
}

class Eq(c: Context) : View(c) {
    var color = Color.WHITE
    private var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun run(b: Boolean) { on = b; invalidate() }
    override fun onDraw(cv: Canvas) {
        val n = 4
        val gap = width * 0.14f
        val bw = (width - gap * (n - 1)) / n
        val t = SystemClock.uptimeMillis() / 1000f
        p.color = color
        for (i in 0 until n) {
            val a = if (on) 0.3f + 0.7f * abs(sin(t * (3.2f + i * 1.1f) + i * 1.7f)) else 0.22f
            val bh = height * a
            val x = i * (bw + gap)
            val y = (height - bh) / 2
            cv.drawRoundRect(x, y, x + bw, y + bh, bw / 2, bw / 2, p)
        }
        if (on && isShown) postInvalidateOnAnimation()
    }
}

class Bar(c: Context) : View(c) {
    var frac = 0f
    var color = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val r = height / 2f
        p.color = Color.argb(60, 255, 255, 255)
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, p)
        p.color = color
        cv.drawRoundRect(0f, 0f, width * frac.coerceIn(0f, 1f), height.toFloat(), r, r, p)
    }
}

class IslandService : AccessibilityService() {
    companion object { @Volatile var instance: IslandService? = null }

    private enum class S { HIDDEN, COMPACT, EXPANDED }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private var watcher: EventWatcher? = null
    private var st = S.HIDDEN
    private var info: MediaInfo? = null
    private var mediaVis = false          // media pill wanted on screen
    private var ev: Ev? = null            // transient pop-up (toggle, charging...)
    private var anim: ValueAnimator? = null
    private var torch = false
    private var lastArt: Bitmap? = null
    private var lastAcc = Color.WHITE
    private var lastPkg = ""
    private var appIcon: Drawable? = null
    private var bubShown = false
    private var lastCfg = 0
    private var winBW = 0

    private val tfMed: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val tfBold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)

    // style (px unless noted)
    private var sPillW = 0; private var sPillH = 0; private var sExpW = 0; private var sExpH = 0; private var sRad = 0
    private var sEvW = 0; private var sOffX = 0; private var sOffY = 0; private var sDur = 450L; private var sBounce = 0.4f
    private var sNotch = false; private var sAccent = true; private var sEq = true; private var sColor = Color.BLACK
    private var sPop = true; private var sBubble = true
    // geometry
    private var cx = 0; private var top = 0; private var holeD = 0
    private var cw = 0; private var ch = 0; private var cr = 0f

    private var root: FrameLayout? = null
    private var body: FrameLayout? = null
    private val bg = GradientDrawable()
    private lateinit var compact: FrameLayout
    private lateinit var mediaC: FrameLayout
    private lateinit var evC: FrameLayout
    private lateinit var artS: ImageView
    private lateinit var eqS: Eq
    private lateinit var evIcon: ImageView
    private lateinit var evLabel: TextView
    private lateinit var evState: TextView
    private lateinit var bub: FrameLayout
    private lateinit var bubImg: ImageView
    private lateinit var full: LinearLayout
    private lateinit var artB: ImageView
    private lateinit var badge: ImageView
    private lateinit var eqB: Eq
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var bar: Bar
    private lateinit var tEl: TextView
    private lateinit var tRem: TextView
    private lateinit var play: ImageView

    private val tick = object : Runnable {
        override fun run() {
            val m = info
            if (m != null && st != S.HIDDEN) {
                val p = m.position()
                if (m.dur > 0) {
                    bar.frac = p.toFloat() / m.dur; bar.invalidate()
                    tEl.text = fmt(p); tRem.text = "-" + fmt(m.dur - p)
                } else { bar.frac = 0f; bar.invalidate(); tEl.text = ""; tRem.text = "" }
            }
            if (st == S.EXPANDED) h.postDelayed(this, 500)
        }
    }
    private val mediaHide = Runnable { mediaVis = false; refresh() }
    private val evEnd = Runnable { ev = null; refresh() }
    private val demoEnd = Runnable {
        val real = MediaBus.current
        info = real
        if (real?.playing != true) { mediaVis = false; refresh() }
    }
    private val restyle = Runnable {
        anim?.cancel(); removeRoot(); st = S.HIDDEN; ev = null
        loadStyle()
        val real = MediaBus.current
        if (real != null && real.playing) { info = real; mediaVis = true; show() } else demo()
    }
    private val prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        h.removeCallbacks(restyle); h.postDelayed(restyle, 150)
    }

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sp = Prefs.sp(this)
        sp.registerOnSharedPreferenceChangeListener(prefL)
        loadStyle()
        watcher = EventWatcher(this, h) { onEvent(it) }.also { it.start() }
        MediaBus.listener = { onMedia(it) }
        MediaBus.current?.let { onMedia(it) }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        anim?.cancel(); removeRoot(); st = S.HIDDEN; ev = null
        val m = MediaBus.current
        info = m
        mediaVis = m?.playing == true
        if (mediaVis) show()
    }

    override fun onUnbind(intent: Intent?): Boolean { cleanup(); return super.onUnbind(intent) }
    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        watcher?.stop(); watcher = null
        anim?.cancel(); removeRoot(); st = S.HIDDEN
        if (instance === this) instance = null
        MediaBus.listener = null
        try { sp.unregisterOnSharedPreferenceChangeListener(prefL) } catch (e: Exception) { }
    }

    // ---------- activities: media (stays) + pop-ups (short) ----------
    private fun onMedia(m: MediaInfo?) {
        info = m
        h.removeCallbacks(mediaHide)
        if (m != null && m.playing) mediaVis = true else h.postDelayed(mediaHide, 4000)
        if (m != null && root != null && st != S.HIDDEN) bindMedia(m)
        refresh()
    }

    private fun onEvent(e: Ev) {
        if (!sPop || st == S.EXPANDED) return
        ev = e
        h.removeCallbacks(evEnd); h.postDelayed(evEnd, 2600)
        if (root != null && st != S.HIDDEN) bindEv(e)
        refresh()
    }

    private fun mainW() = if (ev != null) sEvW else sPillW
    private fun bubbleOn() = sBubble && ev != null && mediaVis && st != S.EXPANDED
    private fun cfgKey() = (if (ev != null) 1 else 0) + (if (bubbleOn()) 2 else 0)
    private fun winBodyW() = if (st == S.EXPANDED) sExpW else mainW() + (if (bubbleOn()) 2 * (sPillH + dp(6)) else 0)

    private fun refresh() {
        val want = mediaVis || ev != null
        if (!want) { if (st == S.COMPACT) hide(); return }
        if (st == S.HIDDEN) { show(); return }
        if (st == S.COMPACT && cfgKey() != lastCfg) retarget()
    }

    /** Fake "now playing" + a Wi-Fi pop-up, to preview the look (Test button / live style preview). */
    fun demo() {
        h.post {
            val real = MediaBus.current
            if (real == null || !real.playing) {
                val d = MediaInfo("Preview", "Punch Island", null, true, 0L, 180000L, SystemClock.elapsedRealtime(), 1f, null, packageName)
                info = d; mediaVis = true
                h.removeCallbacks(mediaHide)
                if (st == S.HIDDEN) show() else if (root != null) { bindMedia(d); refresh() }
                h.removeCallbacks(demoEnd); h.postDelayed(demoEnd, 6500)
            }
            h.postDelayed({ onEvent(Ev(R.drawable.ic_wifi, "Wi-Fi", "On", Color.parseColor("#0A84FF"))) }, 1500)
        }
    }

    // ---------- geometry ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun loadStyle() {
        fun i(k: String) = Prefs.int(sp, k)
        val maxW = resources.displayMetrics.widthPixels
        sPillW = dp(i("pillW")); sPillH = dp(i("pillH"))
        sExpW = min(dp(i("expW")), maxW - dp(16)); sExpH = dp(i("expH")); sRad = dp(i("radius"))
        sEvW = min(sPillW + dp(96), maxW - dp(32))
        sOffX = dp(i("offX")); sOffY = dp(i("offY"))
        sDur = i("dur").toLong(); sBounce = i("bounce") / 100f
        sNotch = sp.getBoolean("notch", false)
        sAccent = sp.getBoolean("accent", true)
        sEq = sp.getBoolean("eq", true)
        sPop = sp.getBoolean("pop", true)
        sBubble = sp.getBoolean("bubble", true)
        sColor = Color.parseColor(Prefs.colors[sp.getInt("color", 0).coerceIn(0, Prefs.colors.lastIndex)])
    }

    /** Finds the camera hole (API 30+); otherwise falls back to top-centre. Sliders fine-tune it. */
    private fun locate() {
        val dm = resources.displayMetrics
        var x = dm.widthPixels / 2f
        var y = statusBarH() / 2f
        var d = dp(22).toFloat()
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val r = wm.currentWindowMetrics.windowInsets.displayCutout?.boundingRects?.minByOrNull { it.top }
                if (r != null && r.top < dm.heightPixels / 4 && r.width() < dm.widthPixels) {
                    x = r.exactCenterX(); y = r.exactCenterY(); d = min(r.width(), r.height()).toFloat()
                }
            } catch (e: Exception) { }
        }
        cx = (x + sOffX).roundToInt()
        top = max(0, (y - sPillH / 2f + sOffY).roundToInt())
        holeD = d.coerceIn(dp(8).toFloat(), sPillH.toFloat()).roundToInt()
    }

    private fun winLp(bw: Int, bh: Int): WindowManager.LayoutParams {
        val w = bw + dp(48)
        val lp = WindowManager.LayoutParams(
            w, bh + dp(32), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        // centre-anchored: resizing the window never shifts the island sideways
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = cx - resources.displayMetrics.widthPixels / 2
        lp.y = top
        if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        lp.title = "PunchIsland"
        return lp
    }

    private fun resizeWindow(bw: Int, bh: Int) {
        root?.let { try { wm.updateViewLayout(it, winLp(bw, bh)) } catch (e: Exception) { } }
    }

    private fun removeRoot() {
        root?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        root = null; body = null
    }

    // ---------- view helpers ----------
    private fun rounded(v: View, f: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(x: View, o: Outline) { o.setRoundRect(0, 0, x.width, x.height, min(x.width, x.height) * f) }
        }
        v.clipToOutline = true
    }

    private fun pressable(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun ico(res: Int, color: Int = Color.WHITE): ImageView {
        val v = ImageView(this)
        try { v.setImageResource(res) } catch (e: Exception) { }
        v.setColorFilter(color)
        return v
    }

    private fun btn(res: Int, pad: Int, circle: Boolean, click: (ImageView) -> Unit): ImageView {
        val v = ico(res)
        v.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        if (circle) v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2C2C2E")) }
        v.setOnClickListener { click(v) }
        pressable(v)
        return v
    }

    private fun build() {
        bubShown = false
        val r = FrameLayout(this)
        r.clipChildren = false
        r.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && st == S.EXPANDED) { collapse(); true } else false
        }

        // second circle: the media app, parked beside the pill while a pop-up owns it
        bub = FrameLayout(this)
        bub.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(sColor) }
        bubImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        rounded(bubImg, 0.5f)
        val bi = (sPillH * 0.62f).roundToInt()
        bub.addView(bubImg, FLP(bi, bi, Gravity.CENTER))
        bub.visibility = View.GONE
        r.addView(bub, FLP(sPillH, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val b = FrameLayout(this)
        bg.setColor(sColor)
        b.background = bg
        b.clipToOutline = true
        b.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, if (sNotch) -cr.roundToInt() else 0, v.width, v.height, cr)
            }
        }
        b.setOnClickListener { if (st == S.COMPACT) expand() else if (st == S.EXPANDED) collapse() }
        r.addView(b, FLP(sPillW, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---- compact: media (art left, equalizer right) / pop-up (icon+name left, state right).
        // Everything sits LEFT and RIGHT of the camera hole, never over it.
        val a = (sPillH * 0.58f).roundToInt()
        val pad = (sPillH * 0.3f).roundToInt()
        mediaC = FrameLayout(this)
        artS = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        rounded(artS, 0.26f)
        mediaC.addView(artS, FLP(a, a, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = pad })
        eqS = Eq(this)
        mediaC.addView(eqS, FLP(a, (a * 0.8f).roundToInt(), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = pad })

        evC = FrameLayout(this)
        evC.alpha = 0f
        evIcon = ico(R.drawable.ic_wifi)
        evC.addView(evIcon, FLP(dp(20), dp(20), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = pad })
        evLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; typeface = tfMed; maxLines = 1 }
        evC.addView(evLabel, FLP(WC, WC, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = pad + dp(26) })
        evState = TextView(this).apply { textSize = 13f; typeface = tfBold; maxLines = 1 }
        evC.addView(evState, FLP(WC, WC, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = pad })

        compact = FrameLayout(this)
        compact.addView(mediaC, FLP(sPillW, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        compact.addView(evC, FLP(sEvW, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        b.addView(compact, FLP(MP, sPillH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---- expanded: art + equalizer flank the hole; text, progress, controls, quick buttons below it
        full = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(14))
            clipChildren = false; clipToPadding = false
            alpha = 0f; visibility = View.INVISIBLE
        }
        val trow = FrameLayout(this).apply { clipChildren = false }
        val box = FrameLayout(this).apply { clipChildren = false }
        artB = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        rounded(artB, 0.22f)
        box.addView(artB, FLP(dp(44), dp(44)))
        badge = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
        rounded(badge, 0.26f)
        box.addView(badge, FLP(dp(19), dp(19), Gravity.END or Gravity.BOTTOM).apply { marginEnd = -dp(5); bottomMargin = -dp(5) })
        trow.addView(box, FLP(dp(44), dp(44), Gravity.START or Gravity.CENTER_VERTICAL))
        eqB = Eq(this)
        trow.addView(eqB, FLP(dp(24), dp(20), Gravity.END or Gravity.CENTER_VERTICAL))
        full.addView(trow, LLP(MP, dp(44)))

        title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; typeface = tfBold; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        artist = TextView(this).apply { setTextColor(Color.argb(150, 255, 255, 255)); textSize = 13f; typeface = tfMed; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        full.addView(title, LLP(MP, WC).apply { topMargin = dp(8) })
        full.addView(artist, LLP(MP, WC))

        bar = Bar(this)
        full.addView(bar, LLP(MP, dp(4)).apply { topMargin = dp(12) })
        val times = FrameLayout(this)
        tEl = TextView(this).apply { setTextColor(Color.argb(130, 255, 255, 255)); textSize = 11f; typeface = tfMed }
        tRem = TextView(this).apply { setTextColor(Color.argb(130, 255, 255, 255)); textSize = 11f; typeface = tfMed }
        times.addView(tEl, FLP(WC, WC, Gravity.START))
        times.addView(tRem, FLP(WC, WC, Gravity.END))
        full.addView(times, LLP(MP, WC).apply { topMargin = dp(4) })

        val ctr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        ctr.addView(btn(R.drawable.ic_prev, 13, false) { info?.ctl?.transportControls?.skipToPrevious() }, LLP(dp(56), dp(56)))
        play = btn(R.drawable.ic_pause, 11, false) {
            val m = info
            if (m != null) {
                val t = m.ctl?.transportControls
                if (t != null) { if (m.playing) t.pause() else t.play() }
            }
        }
        ctr.addView(play, LLP(dp(64), dp(64)).apply { setMargins(dp(14), 0, dp(14), 0) })
        ctr.addView(btn(R.drawable.ic_next, 13, false) { info?.ctl?.transportControls?.skipToNext() }, LLP(dp(56), dp(56)))
        full.addView(ctr, LLP(MP, 0, 1f))

        val act = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun lp() = LLP(dp(40), dp(40)).apply { setMargins(dp(9), 0, dp(9), 0) }
        act.addView(btn(R.drawable.ic_flash, 10, true) { torchToggle(it) }, lp())
        act.addView(btn(R.drawable.ic_camera, 10, true) { launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, lp())
        act.addView(btn(R.drawable.ic_timer, 10, true) { launch(Intent(AlarmClock.ACTION_SHOW_TIMERS)) }, lp())
        act.addView(btn(R.drawable.ic_shot, 10, true) { shot() }, lp())
        act.addView(btn(R.drawable.ic_lock, 10, true) { global(GLOBAL_ACTION_LOCK_SCREEN) }, lp())
        full.addView(act, LLP(MP, dp(40)).apply { topMargin = dp(6) })
        b.addView(full, FLP(sExpW, sExpH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        root = r; body = b
    }

    // ---------- content ----------
    private fun fmt(ms: Long): String {
        val s = max(0L, ms / 1000)
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    private fun appIconFor(pkg: String): Drawable? {
        if (pkg.isEmpty()) return null
        if (pkg != lastPkg) {
            lastPkg = pkg
            appIcon = try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
        }
        return appIcon
    }

    private fun setArt(iv: ImageView, bm: Bitmap?, ic: Drawable?) {
        iv.clearColorFilter(); iv.background = null; iv.setPadding(0, 0, 0, 0)
        when {
            bm != null -> iv.setImageBitmap(bm)
            ic != null -> iv.setImageDrawable(ic)
            else -> {
                iv.setImageResource(R.drawable.ic_note); iv.setColorFilter(Color.WHITE)
                iv.setBackgroundColor(Color.parseColor("#2C2C2E"))
                val p = dp(5); iv.setPadding(p, p, p, p)
            }
        }
    }

    private fun accentOf(b: Bitmap): Int = try {
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        if (hsv[1] < 0.15f) Color.WHITE else { hsv[1] = max(hsv[1], 0.5f); hsv[2] = max(hsv[2], 0.9f); Color.HSVToColor(hsv) }
    } catch (e: Exception) { Color.WHITE }

    private fun bindMedia(m: MediaInfo) {
        title.text = m.title.ifBlank { "Playing" }
        artist.text = m.artist
        val ic = appIconFor(m.pkg)
        val bm = m.art
        setArt(artS, bm, ic); setArt(artB, bm, ic); setArt(bubImg, bm, ic)
        if (ic != null && bm != null) { badge.setImageDrawable(ic); badge.visibility = View.VISIBLE } else badge.visibility = View.GONE
        play.setImageResource(if (m.playing) R.drawable.ic_pause else R.drawable.ic_play)
        if (bm !== lastArt) { lastArt = bm; lastAcc = if (bm != null) accentOf(bm) else Color.WHITE }
        val acc = if (sAccent) lastAcc else Color.WHITE
        eqS.color = acc; eqB.color = acc; bar.color = acc
        val vis = if (sEq) View.VISIBLE else View.INVISIBLE
        eqS.visibility = vis; eqB.visibility = vis
        eqS.run(m.playing && sEq); eqB.run(m.playing && sEq)
        h.removeCallbacks(tick); h.post(tick)
    }

    private fun bindEv(e: Ev) {
        try { evIcon.setImageResource(e.icon) } catch (x: Exception) { }
        evIcon.setColorFilter(e.color)
        evLabel.text = e.label
        evState.text = e.state
        evState.setTextColor(e.color)
    }

    private fun bindAll() {
        info?.let { bindMedia(it) }
        ev?.let { bindEv(it) }
    }

    // ---------- animation ----------
    private fun place(w: Int, hh: Int, r: Float) {
        val b = body ?: return
        cw = w; ch = hh; cr = r
        val lp = b.layoutParams as FrameLayout.LayoutParams
        lp.width = w; lp.height = hh; lp.topMargin = max(0, (sPillH - hh) / 2)
        b.layoutParams = lp
        val t = if (sNotch) 0f else r
        bg.cornerRadii = floatArrayOf(t, t, t, t, r, r, r, r)
        b.invalidateOutline()
    }

    private fun morph(tw: Int, th: Int, tr: Float, end: (() -> Unit)?) {
        anim?.cancel()
        val w0 = cw; val h0 = ch; val r0 = cr
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = sDur
        a.interpolator = Spring(sBounce)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            val w = (w0 + (tw - w0) * f).roundToInt().coerceAtLeast(1)
            val hh = (h0 + (th - h0) * f).roundToInt().coerceAtLeast(1)
            place(w, hh, (r0 + (tr - r0) * f).coerceIn(0f, min(w, hh) / 2f))
        }
        a.addListener(object : AnimatorListenerAdapter() {
            var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) {
                if (cancelled) return
                place(tw, th, tr.coerceIn(0f, min(tw, th) / 2f))
                end?.invoke()
            }
        })
        anim = a
        a.start()
    }

    private fun showCompactContent(animate: Boolean) {
        val e = ev != null
        val d = if (animate) sDur * 30 / 100 else 0L
        mediaC.animate().alpha(if (e) 0f else 1f).setStartDelay(0).setDuration(d).start()
        evC.animate().alpha(if (e) 1f else 0f).setStartDelay(0).setDuration(d).start()
    }

    /** The second circle splits off the pill (and merges back) when two activities are live. */
    private fun syncBubble(animate: Boolean) {
        val want = bubbleOn()
        val rest = sPillW / 2f - sPillH / 2f
        val target = mainW() / 2f + dp(6) + sPillH / 2f
        if (want) {
            if (!bubShown) { bub.visibility = View.VISIBLE; bub.translationX = rest; bub.scaleX = 0.4f; bub.scaleY = 0.4f; bub.alpha = 0f }
            if (animate) bub.animate().translationX(target).scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(0)
                .setDuration(sDur).setInterpolator(Spring(sBounce)).start()
            else { bub.translationX = target; bub.scaleX = 1f; bub.scaleY = 1f; bub.alpha = 1f }
        } else if (bubShown) {
            bub.animate().translationX(rest).scaleX(0.4f).scaleY(0.4f).alpha(0f).setStartDelay(0)
                .setDuration(sDur * 60 / 100).setInterpolator(DecelerateInterpolator())
                .withEndAction { bub.visibility = View.GONE }.start()
        }
        bubShown = want
    }

    private fun show() {
        if (st != S.HIDDEN) return
        if (resources.configuration.orientation != Configuration.ORIENTATION_PORTRAIT) return
        anim?.cancel(); removeRoot()
        loadStyle(); locate(); build()
        winBW = winBodyW()
        try { wm.addView(root, winLp(winBW, sPillH)) } catch (e: Exception) { removeRoot(); return }
        st = S.COMPACT
        lastCfg = cfgKey()
        place(holeD, holeD, holeD / 2f)           // start as a dot exactly over the camera hole
        bindAll()
        showCompactContent(false)
        syncBubble(false)
        compact.alpha = 0f
        compact.animate().alpha(1f).setStartDelay(sDur * 35 / 100).setDuration(sDur * 40 / 100).start()
        morph(mainW(), sPillH, sPillH / 2f, null) // the widening animation
    }

    private fun hide() {
        if (st == S.HIDDEN) return
        h.removeCallbacks(tick)
        st = S.HIDDEN
        val d = sDur * 25 / 100
        compact.animate().alpha(0f).setStartDelay(0).setDuration(d).start()
        full.animate().alpha(0f).setStartDelay(0).setDuration(d).start()
        bub.animate().alpha(0f).setStartDelay(0).setDuration(d).start()
        morph(holeD, holeD, holeD / 2f) { removeRoot() }
    }

    /** Pill changes shape for a new activity (media <-> pop-up, second circle in/out). */
    private fun retarget() {
        if (st != S.COMPACT) return
        lastCfg = cfgKey()
        val want = winBodyW()
        resizeWindow(max(winBW, want), sPillH)    // grow first so nothing is clipped...
        winBW = max(winBW, want)
        bindAll()
        showCompactContent(true)
        syncBubble(true)
        morph(mainW(), sPillH, sPillH / 2f) {      // ...and shrink once settled
            if (st == S.COMPACT) { winBW = winBodyW(); resizeWindow(winBW, sPillH) }
        }
    }

    private fun expand() {
        if (st != S.COMPACT || info == null) return
        ev = null; h.removeCallbacks(evEnd)
        st = S.EXPANDED
        resizeWindow(max(winBW, sExpW), sExpH)
        winBW = max(winBW, sExpW)
        syncBubble(true)
        bindAll()
        compact.animate().alpha(0f).setStartDelay(0).setDuration(sDur * 25 / 100).start()
        full.visibility = View.VISIBLE
        full.alpha = 0f; full.scaleX = 0.9f; full.scaleY = 0.9f
        full.pivotX = sExpW / 2f; full.pivotY = 0f
        full.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(sDur * 30 / 100).setDuration(sDur * 55 / 100).start()
        morph(sExpW, sExpH, sRad.toFloat(), null)
        h.post(tick)
    }

    private fun collapse() {
        if (st != S.EXPANDED) return
        st = S.COMPACT
        h.removeCallbacks(tick)
        full.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setStartDelay(0).setDuration(sDur * 25 / 100)
            .withEndAction { full.visibility = View.INVISIBLE }.start()
        showCompactContent(false)
        compact.animate().alpha(1f).setStartDelay(sDur * 35 / 100).setDuration(sDur * 40 / 100).start()
        lastCfg = cfgKey()
        morph(mainW(), sPillH, sPillH / 2f) {
            if (st == S.COMPACT) { winBW = winBodyW(); resizeWindow(winBW, sPillH) }
            refresh()
        }
    }

    // ---------- quick buttons ----------
    private fun launch(i: Intent) {
        collapse()
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) } catch (e: Exception) { }
    }

    private fun global(action: Int) {
        collapse()
        h.postDelayed({ if (Build.VERSION.SDK_INT >= 28) performGlobalAction(action) }, 300)
    }

    private fun shot() {
        root?.visibility = View.INVISIBLE      // screenshot without the island
        collapse()
        h.postDelayed({ if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) }, 450)
        h.postDelayed({ root?.visibility = View.VISIBLE }, 1800)
    }

    private fun torchToggle(v: ImageView) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torch = !torch
            cm.setTorchMode(id, torch)
            (v.background as? GradientDrawable)?.setColor(Color.parseColor(if (torch) "#FFD60A" else "#2C2C2E"))
            v.setColorFilter(if (torch) Color.BLACK else Color.WHITE)
        } catch (e: Exception) { }
    }
}
