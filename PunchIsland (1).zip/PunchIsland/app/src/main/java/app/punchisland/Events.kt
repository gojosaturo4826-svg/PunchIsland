package app.punchisland

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import kotlin.math.max

/** A short pop-up shown on the island (a quick-settings toggle, charging, ringer...). */
class Ev(val icon: Int, val label: String, val state: String, val color: Int)

class EventWatcher(private val c: Context, private val h: Handler, private val out: (Ev) -> Unit) {
    private val armed = SystemClock.elapsedRealtime() + 1500   // ignore startup / sticky callbacks
    private val torchSeen = HashMap<String, Boolean>()
    private val gray = Color.parseColor("#8E8E93")

    private fun ok() = SystemClock.elapsedRealtime() > armed

    private fun toggle(icon: Int, label: String, on: Boolean, col: String) {
        if (ok()) out(Ev(icon, label, if (on) "On" else "Off", if (on) Color.parseColor(col) else gray))
    }

    private fun charging(on: Boolean) {
        if (!ok()) return
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val pct = if (b != null) b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / max(1, b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)) else 0
        out(Ev(R.drawable.ic_batt, if (on) "Charging" else "Unplugged", "$pct%", if (on) Color.parseColor("#30D158") else gray))
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, i: Intent) {
            when (i.action) {
                WifiManager.WIFI_STATE_CHANGED_ACTION -> when (i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)) {
                    WifiManager.WIFI_STATE_ENABLED -> toggle(R.drawable.ic_wifi, "Wi-Fi", true, "#0A84FF")
                    WifiManager.WIFI_STATE_DISABLED -> toggle(R.drawable.ic_wifi, "Wi-Fi", false, "#0A84FF")
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                    BluetoothAdapter.STATE_ON -> toggle(R.drawable.ic_bt, "Bluetooth", true, "#0A84FF")
                    BluetoothAdapter.STATE_OFF -> toggle(R.drawable.ic_bt, "Bluetooth", false, "#0A84FF")
                }
                Intent.ACTION_AIRPLANE_MODE_CHANGED ->
                    toggle(R.drawable.ic_air, "Airplane", i.getBooleanExtra("state", false), "#FF9F0A")
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    val f = (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).currentInterruptionFilter
                    if (f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
                        toggle(R.drawable.ic_moon, "DND", f != NotificationManager.INTERRUPTION_FILTER_ALL, "#5E5CE6")
                }
                AudioManager.RINGER_MODE_CHANGED_ACTION -> if (ok()) when (i.getIntExtra(AudioManager.EXTRA_RINGER_MODE, -1)) {
                    AudioManager.RINGER_MODE_SILENT -> out(Ev(R.drawable.ic_vol_off, "Ringer", "Silent", Color.parseColor("#FF453A")))
                    AudioManager.RINGER_MODE_VIBRATE -> out(Ev(R.drawable.ic_bell, "Ringer", "Vibrate", Color.parseColor("#FF9F0A")))
                    AudioManager.RINGER_MODE_NORMAL -> out(Ev(R.drawable.ic_vol_up, "Ringer", "Ring", Color.WHITE))
                }
                PowerManager.ACTION_POWER_SAVE_MODE_CHANGED ->
                    toggle(R.drawable.ic_batt, "Saver", (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode, "#FFD60A")
                Intent.ACTION_POWER_CONNECTED -> charging(true)
                Intent.ACTION_POWER_DISCONNECTED -> charging(false)
            }
        }
    }

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            val prev = torchSeen.put(id, enabled)
            if (prev != null && prev != enabled) toggle(R.drawable.ic_flash, "Flashlight", enabled, "#FFD60A")
        }
    }

    private val obs = object : ContentObserver(h) {
        override fun onChange(selfChange: Boolean) {
            val on = Settings.System.getInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
            toggle(R.drawable.ic_rotate, "Rotate", on, "#FF9F0A")
        }
    }

    fun start() {
        val f = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else c.registerReceiver(rx, f)
        } catch (e: Exception) { }
        try { (c.getSystemService(Context.CAMERA_SERVICE) as CameraManager).registerTorchCallback(torchCb, h) } catch (e: Exception) { }
        try {
            c.contentResolver.registerContentObserver(Settings.System.getUriFor(Settings.System.ACCELEROMETER_ROTATION), false, obs)
        } catch (e: Exception) { }
    }

    fun stop() {
        try { c.unregisterReceiver(rx) } catch (e: Exception) { }
        try { (c.getSystemService(Context.CAMERA_SERVICE) as CameraManager).unregisterTorchCallback(torchCb) } catch (e: Exception) { }
        try { c.contentResolver.unregisterContentObserver(obs) } catch (e: Exception) { }
    }
}
