plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "app.punchisland"
    compileSdk = 34
    signingConfigs {
        getByName("debug") {
            storeFile = file("island.p12")
            storePassword = "punchisland"
            keyAlias = "island"
            keyPassword = "punchisland"
            storeType = "pkcs12"
        }
    }
    defaultConfig {
        applicationId = "app.punchisland"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
